package com.mien.mod.fabric;

import com.mien.mod.MienConfig;
import com.mien.mod.MienRenderHelper;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.class_1007;
import net.minecraft.class_1299;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_742;
import org.joml.Matrix4f;

/**
 * 把嘴巴贴图贴在玩家头部模型的正前方。
 * 作为玩家渲染器的 FeatureRenderer 注册，渲染时矩阵处于实体模型空间。
 */
public final class MienFabric3DRenderer extends class_3887<class_742, class_591<class_742>> {
    // 头部方块在模型像素空间：x/z 为 -4..4，y 为 -8..0（y 轴向下），脸部正前方为 z = -4。
    private static final float FACE_CENTER_Y = -4.0F;
    private static final float FACE_HALF_SIZE = 4.0F;
    private static final float FACE_Z = -4.0F;
    // 原版 ModelPart$Cuboid 构建顶点时统一除以 16，这里用同样的比例把像素坐标换算为方块坐标。
    private static final float MODEL_SCALE = 1.0F / 16.0F;
    // 0.1 像素（约 0.00625 方块）的外移量，足以避免与脸部皮肤 Z-fighting。
    private static final float FACE_OFFSET = 0.1F;

    private MienFabric3DRenderer(class_3883<class_742, class_591<class_742>> context) {
        super(context);
    }

    public static void register() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
            if (entityType == class_1299.field_6097 && entityRenderer instanceof class_1007 playerRenderer) {
                registrationHelper.register(new MienFabric3DRenderer(playerRenderer));
            }
        });
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 entity,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (entity.method_5767()) {
            return;
        }
        if (!MienRenderHelper.hasMouthTexture(class_310.method_1551(), MienRenderHelper.currentState)) {
            return;
        }

        class_2960 texture = MienRenderHelper.getMouthTexture(MienRenderHelper.currentState);
        class_4588 buffer = vertexConsumers.getBuffer(class_1921.method_23580(texture));

        matrices.method_22903();
        // 进入头部部件局部空间，跟随头部俯仰与左右转动。
        this.method_17165().field_3398.method_22703(matrices);

        // 来自调参界面的参数：偏移单位为皮肤像素，缩放围绕脸部中心。
        MienConfig config = MienConfig.getInstance();
        float scale = config == null ? 1.0F : config.getMouthScale();
        float offsetX = config == null ? 0.0F : config.mouth_offset_x;
        float offsetY = config == null ? 0.0F : config.mouth_offset_y;

        matrices.method_46416(0.0F, FACE_CENTER_Y * MODEL_SCALE, 0.0F);
        matrices.method_46416(offsetX * MODEL_SCALE, offsetY * MODEL_SCALE, 0.0F);
        matrices.method_22905(scale, scale, scale);

        class_4587.class_4665 entry = matrices.method_23760();
        Matrix4f positionMatrix = entry.method_23761();
        // 脸部所在平面为 z = -4 像素，再向外偏移 0.1 像素避免 Z-fighting。
        float z = (FACE_Z - FACE_OFFSET) * MODEL_SCALE;
        float half = FACE_HALF_SIZE * MODEL_SCALE;

        // 顶点顺序与 ModelPart$Cuboid 的 -Z（脸部）面一致：左上 → 右上 → 右下 → 左下。
        vertex(buffer, entry, positionMatrix, -half, -half, z, 0.0F, 0.0F, light);
        vertex(buffer, entry, positionMatrix, half, -half, z, 1.0F, 0.0F, light);
        vertex(buffer, entry, positionMatrix, half, half, z, 1.0F, 1.0F, light);
        vertex(buffer, entry, positionMatrix, -half, half, z, 0.0F, 1.0F, light);

        matrices.method_22909();
    }

    private static void vertex(class_4588 buffer, class_4587.class_4665 entry, Matrix4f positionMatrix,
                               float x, float y, float z, float u, float v, int light) {
        buffer.method_22918(positionMatrix, x, y, z)
                .method_1336(255, 255, 255, 255)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_60831(entry, 0.0F, 0.0F, -1.0F);
    }
}

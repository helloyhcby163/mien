package com.mien.mod.fabric;

import com.mien.mod.MienConfig;
import com.mien.mod.MienRenderHelper;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.class_1007;
import net.minecraft.class_1299;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_742;
import org.joml.Matrix4f;

/**
 * 把嘴巴贴图贴在玩家头部模型的正前方。
 * 作为玩家渲染器的 FeatureRenderer 注册，渲染时矩阵处于实体模型空间。
 */
public final class MienFabric3DRenderer extends class_3887<class_742, class_591<class_742>> {
    // 头部方块在模型像素空间：x/z 为 -4..4，y 为 -8..0（y 轴向下），脸部正前方为 z = -4 像素。
    private static final float FACE_Z = 4.0F;
    // 原版 ModelPart$Cuboid 构建顶点时统一除以 16，这里用同样的比例把像素坐标换算为方块坐标。
    private static final float MODEL_SCALE = 1.0F / 16.0F;
    // 照抄原版 CapeFeatureRenderer：matrices.translate(0.0F, 0.0F, 0.125F) 的深度外移量（方块单位）。
    private static final float DEPTH_OFFSET = 0.125F;

    private static String lastLogged = "";

    private MienFabric3DRenderer(class_3883<class_742, class_591<class_742>> context) {
        super(context);
    }

    public static void register() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
            if (entityType == class_1299.field_6097 && entityRenderer instanceof class_1007 playerRenderer) {
                registrationHelper.register(new MienFabric3DRenderer(playerRenderer));
            }
        });
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 entity,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (entity.method_5767()) {
            return;
        }
        String state = MienRenderHelper.currentState;
        if (!MienRenderHelper.hasMouthTexture(class_310.method_1551(), state)) {
            return;
        }

        MienConfig config = MienConfig.getInstance();
        MienConfig.StateData data = MienRenderHelper.getStateData(state);
        if (config == null || config.face == null || data == null) {
            return;
        }

        // 皮肤 64x64 空间的 x / y 映射到头部模型像素空间：
        // 脸部左/上边缘 face.x / face.y 对应模型 x = -size/2、y = -size，幅度不变。
        float centerX = (data.x - config.face.x) - config.face.size / 2.0F;
        float centerY = (data.y - config.face.y) - config.face.size;
        float halfWidth = data.w / 2.0F;
        float halfHeight = data.h / 2.0F;

        class_2960 texture = MienRenderHelper.getMouthTexture(state);
        class_4588 buffer = vertexConsumers.getBuffer(class_1921.method_23580(texture));

        matrices.method_22903();
        // 进入头部部件局部空间，跟随头部俯仰与左右转动。
        this.method_17165().field_3398.method_22703(matrices);

        // 先平移到嘴巴中心，再单独沿 -Z 外移；深度不参与任何缩放，避免缩放后陷进头部导致消失。
        matrices.method_46416(centerX * MODEL_SCALE, centerY * MODEL_SCALE, -(FACE_Z * MODEL_SCALE + DEPTH_OFFSET));

        class_4587.class_4665 entry = matrices.method_23760();
        Matrix4f positionMatrix = entry.method_23761();
        float halfW = halfWidth * MODEL_SCALE;
        float halfH = halfHeight * MODEL_SCALE;

        if (!lastLogged.equals(state + data.x + "," + data.y + "," + data.w + "," + data.h)) {
            lastLogged = state + data.x + "," + data.y + "," + data.w + "," + data.h;
            System.out.println("[Mien] 3D state=" + state
                    + " x=" + data.x + " y=" + data.y + " w=" + data.w + " h=" + data.h
                    + " -> center=(" + centerX + ", " + centerY + ")px"
                    + " half=(" + halfW + ", " + halfH + ")block"
                    + " z=" + -(FACE_Z * MODEL_SCALE + DEPTH_OFFSET)
                    + " matrix=" + positionMatrix);
        }

        // 顶点顺序与 ModelPart$Cuboid 的 -Z（脸部）面一致：左上 → 右上 → 右下 → 左下。
        vertex(buffer, entry, positionMatrix, -halfW, -halfH, 0.0F, 0.0F, 0.0F, light);
        vertex(buffer, entry, positionMatrix, halfW, -halfH, 0.0F, 1.0F, 0.0F, light);
        vertex(buffer, entry, positionMatrix, halfW, halfH, 0.0F, 1.0F, 1.0F, light);
        vertex(buffer, entry, positionMatrix, -halfW, halfH, 0.0F, 0.0F, 1.0F, light);

        matrices.method_22909();
    }

    private static void vertex(class_4588 buffer, class_4587.class_4665 entry, Matrix4f positionMatrix,
                               float x, float y, float z, float u, float v, int light) {
        buffer.method_22918(positionMatrix, x, y, z)
                .method_1336(255, 255, 255, 255)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_60831(entry, 0.0F, 0.0F, -1.0F);
    }
}

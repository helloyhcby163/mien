package com.mien.mod.fabric;

import com.mien.mod.MienRenderHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public final class MienFabricHud implements HudRenderCallback {
    private MienFabricHud() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register(new MienFabricHud());
    }

    @Override
    public void onHudRender(class_332 drawContext, class_9779 tickCounter) {
        MienRenderHelper.renderMouthPreview(drawContext, class_310.method_1551());
    }
}

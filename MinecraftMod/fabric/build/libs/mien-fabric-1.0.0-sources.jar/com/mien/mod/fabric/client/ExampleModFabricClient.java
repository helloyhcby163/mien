package com.mien.mod.fabric.client;

import com.mien.mod.AnimationStateMachine;
import com.mien.mod.fabric.MienFabric3DRenderer;
import com.mien.mod.fabric.MienFabricHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ExampleModFabricClient implements ClientModInitializer {
    private static final class_304 CYCLE_STATE_KEY = KeyBindingHelper.registerKeyBinding(
            new class_304("key.mien.cycle_state", class_3675.class_307.field_1668, GLFW.GLFW_KEY_M, "Mien")
    );

    private static final class_304 HOLD_STATE_KEY = KeyBindingHelper.registerKeyBinding(
            new class_304("key.mien.hold_state", class_3675.class_307.field_1668, GLFW.GLFW_KEY_H, "Mien")
    );

    private static final class_304 TOGGLE_STATE_KEY = KeyBindingHelper.registerKeyBinding(
            new class_304("key.mien.toggle_state", class_3675.class_307.field_1668, GLFW.GLFW_KEY_J, "Mien")
    );

    private static final class_304 OPEN_CONFIG_KEY = KeyBindingHelper.registerKeyBinding(
            new class_304("key.mien.open_config", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, "Mien")
    );

    private static boolean holdActive;

    @Override
    public void onInitializeClient() {
        // This entrypoint is suitable for setting up client-specific logic, such as rendering.
        MienFabricHud.register();
        MienFabric3DRenderer.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (CYCLE_STATE_KEY.method_1436()) {
                AnimationStateMachine.cycle();
            }
            while (TOGGLE_STATE_KEY.method_1436()) {
                AnimationStateMachine.toggle();
            }
            while (OPEN_CONFIG_KEY.method_1436()) {
                client.method_1507(new MienConfigScreen());
            }

            // HOLD：按住 H 张嘴，松开恢复 flat。
            boolean holdDown = client.field_1755 == null && HOLD_STATE_KEY.method_1434();
            if (holdDown != holdActive) {
                holdActive = holdDown;
                if (holdDown) {
                    AnimationStateMachine.onHoldStart();
                } else {
                    AnimationStateMachine.onHoldEnd();
                }
            }
        });
    }
}

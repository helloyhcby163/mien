package com.mien.mod.neoforge.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

/**
 * NeoForge 客户端入口：注册 G 键并打开调参界面。
 */
public final class MienNeoForgeClient {
    private static final KeyMapping OPEN_CONFIG_KEY = new KeyMapping(
            "key.mien.open_config", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "Mien"
    );

    private MienNeoForgeClient() {
    }

    public static void register(IEventBus modEventBus) {
        modEventBus.addListener(MienNeoForgeClient::onRegisterKeyMappings);
        NeoForge.EVENT_BUS.addListener(MienNeoForgeClient::onClientTick);
    }

    private static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_CONFIG_KEY);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        while (OPEN_CONFIG_KEY.consumeClick()) {
            Minecraft.getInstance().setScreen(new MienConfigScreen());
        }
    }
}

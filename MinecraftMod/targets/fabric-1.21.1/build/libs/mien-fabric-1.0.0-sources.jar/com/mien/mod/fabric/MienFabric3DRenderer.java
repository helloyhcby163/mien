package com.mien.mod.fabric;

import com.mien.mod.core.AnimationStateMachine;
import com.mien.mod.core.MienPlatforms;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.class_1007;
import net.minecraft.class_1299;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_742;

/**
 * 把嘴巴贴图贴在玩家头部模型的正前方。
 * 只负责注册、可见性判断与头部旋转；绘制入口统一走 MienPlatform.mouthRenderer()。
 */
public final class MienFabric3DRenderer extends class_3887<class_742, class_591<class_742>> {

    private MienFabric3DRenderer(class_3883<class_742, class_591<class_742>> context) {
        super(context);
    }

    public static void register() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
            if (entityType == class_1299.field_6097 && entityRenderer instanceof class_1007 playerRenderer) {
                registrationHelper.register(new MienFabric3DRenderer(playerRenderer));
            }
        });
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 entity,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (entity.method_5767()) {
            return;
        }

        matrices.method_22903();
        // 进入头部部件局部空间，跟随头部俯仰与左右转动。
        this.method_17165().field_3398.method_22703(matrices);
        MienPlatforms.get().mouthRenderer().renderHeadMouth(
                matrices, vertexConsumers, light, AnimationStateMachine.currentState);
        matrices.method_22909();
    }
}

package com.mien.mod.fabric;

import com.mien.mod.core.spi.MouthRenderer;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

/**
 * Fabric 的嘴巴渲染实现。common 只看到 MouthRenderer 接口，
 * 平台类型在这里转换，绘制逻辑复用 MienRenderHelper。
 */
public final class MienFabricMouthRenderer implements MouthRenderer {

    @Override
    public void renderFacePreview(Object drawContext, int previewX, int previewY, int previewSize, String state) {
        if (!(drawContext instanceof class_332 context)) {
            return;
        }
        MienRenderHelper.renderFaceAndMouth(context, class_310.method_1551(),
                previewX, previewY, previewSize, state);
    }

    @Override
    public void renderHeadMouth(Object matrixStack, Object vertexConsumers, int packedLight, String state) {
        if (!(matrixStack instanceof class_4587 matrices)
                || !(vertexConsumers instanceof class_4597 providers)) {
            return;
        }
        MienRenderHelper.renderHeadMouth(matrices, providers, packedLight, state);
    }

    @Override
    public boolean isTextureAvailable(String state) {
        return MienRenderHelper.hasMouthTexture(class_310.method_1551(), state);
    }
}

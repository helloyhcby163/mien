package com.mien.mod.neoforge;

import com.mien.mod.core.AnimationStateMachine;
import com.mien.mod.core.MienPlatforms;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/**
 * 把嘴巴贴图贴在玩家头部模型的正前方。
 * 只负责注册、可见性判断与头部旋转；绘制入口统一走 MienPlatform.mouthRenderer()。
 */
public final class MienNeoForge3DRenderer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    private MienNeoForge3DRenderer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> context) {
        super(context);
    }

    public static void register(IEventBus modEventBus) {
        modEventBus.addListener(MienNeoForge3DRenderer::onAddLayers);
    }

    private static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        for (PlayerSkin.Model model : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(model);
            if (renderer != null) {
                renderer.addLayer(new MienNeoForge3DRenderer(renderer));
            }
        }
    }

    @Override
    public void render(PoseStack matrices, MultiBufferSource vertexConsumers, int light, AbstractClientPlayer entity,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (entity.isInvisible()) {
            return;
        }

        matrices.pushPose();
        // 进入头部部件局部空间，跟随头部俯仰与左右转动。
        this.getParentModel().head.translateAndRotate(matrices);
        MienPlatforms.get().mouthRenderer().renderHeadMouth(
                matrices, vertexConsumers, light, AnimationStateMachine.currentState);
        matrices.popPose();
    }
}

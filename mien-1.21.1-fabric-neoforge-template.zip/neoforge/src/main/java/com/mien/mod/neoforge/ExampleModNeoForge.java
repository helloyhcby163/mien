package com.mien.mod.neoforge;

import net.neoforged.fml.common.Mod;

import com.mien.mod.ExampleMod;

@Mod(ExampleMod.MOD_ID)
public final class ExampleModNeoForge {
    public ExampleModNeoForge() {
        // Run our common setup.
        ExampleMod.init();
    }
}
